﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using HolidayInn;
using HolidayInn.Controllers;

namespace HolidayInn.Tests.Controllers
{
    [TestFixture]
    public class HomeControllerTest
    {
        [Test]
        public void TestNewBooking()
        {
            // Arrange
            var controller = new BookingController();

            var booking = controller.NewBooking();

            Assert.AreEqual(booking.CustomerName, "Test");
        }
    }
}
