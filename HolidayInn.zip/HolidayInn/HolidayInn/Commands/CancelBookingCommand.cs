﻿using System;
namespace HolidayInn.Commands
{
    public class CancelBookingCommand
    {
        public CancelBookingCommand()
        {
        }
    }
}
