﻿using System;
namespace HolidayInn.Commands
{
    public class CreateBookingCommand
    {
        public CreateBookingCommand()
        {
        }
    }
}
