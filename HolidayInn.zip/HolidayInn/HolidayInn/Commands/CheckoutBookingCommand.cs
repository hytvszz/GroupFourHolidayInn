﻿using System;
namespace HolidayInn.Commands
{
    public class CheckoutBookingCommand
    {
        public CheckoutBookingCommand()
        {
        }
    }
}
