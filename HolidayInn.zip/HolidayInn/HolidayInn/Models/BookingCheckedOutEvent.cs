﻿using System;
using EventFlow.Aggregates;

namespace HolidayInn.Models
{
    public class BookingCheckedOutEvent : AggregateEvent<BookingAggregate, BookingId>
    {
        public BookingCheckedOutEvent()
        {
        }
    }
}
