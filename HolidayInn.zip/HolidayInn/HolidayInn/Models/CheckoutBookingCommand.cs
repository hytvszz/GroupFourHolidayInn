﻿using System;
using EventFlow.Commands;

namespace HolidayInn.Models
{
    public class CheckoutBookingCommand : Command<BookingAggregate, BookingId>
    {
        public CheckoutBookingCommand(BookingId aggregateId) : base(aggregateId)
        {
        }
    }
}
