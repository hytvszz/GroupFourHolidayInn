﻿using System;
using System.Threading;
using System.Threading.Tasks;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace HolidayInn.Models
{
    public class CreateBookingCommandHandler : CommandHandler<BookingAggregate, BookingId, IExecutionResult, CreateBookingCommand>
    {
        public CreateBookingCommandHandler()
        {
        }

        public override Task<IExecutionResult> ExecuteCommandAsync(BookingAggregate aggregate, CreateBookingCommand command, CancellationToken cancellationToken)
        {
            aggregate.Create(command.Booking);
            return Task.FromResult(ExecutionResult.Success());
        }
    }
}
