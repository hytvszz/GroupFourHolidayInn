﻿using System;
using EventFlow.Commands;

namespace HolidayInn.Models
{
    public class CancelBookingCommand : Command<BookingAggregate, BookingId>
    {
        public CancelBookingCommand(BookingId id) : base(id)
        {

        }
    }
}
