﻿using System;
using System.Threading;
using System.Threading.Tasks;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace HolidayInn.Models
{
    public class CancelBookingCommandHandler : CommandHandler<BookingAggregate, BookingId, IExecutionResult, CancelBookingCommand>
    {
        public CancelBookingCommandHandler()
        {
        }

        public override System.Threading.Tasks.Task<IExecutionResult> ExecuteCommandAsync(BookingAggregate aggregate, CancelBookingCommand command, CancellationToken cancellationToken)
        {
            aggregate.Cancel();
            return Task.FromResult(ExecutionResult.Success());
        }
    }
}
