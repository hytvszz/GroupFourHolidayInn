﻿using System;
using EventFlow.Commands;

namespace HolidayInn.Models
{
    public class CreateBookingCommand : Command<BookingAggregate, BookingId>
    {
        public Booking Booking { get; private set; }

        public CreateBookingCommand(Booking booking) : base(booking.Id)
        {
            this.Booking = booking;
        }
    }
}
