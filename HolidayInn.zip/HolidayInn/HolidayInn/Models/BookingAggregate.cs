﻿using System;
using EventFlow.Aggregates;
using EventFlow.Exceptions;

namespace HolidayInn.Models
{
    public class BookingAggregate : AggregateRoot<BookingAggregate, BookingId>, IEmit<BookingCreatedEvent>, IEmit<BookingCancelledEvent>, IEmit<BookingCheckedOutEvent>
    {
        private Booking Booking;

        public BookingAggregate(Booking booking)
          : base(booking.Id)
        {

        }

        public void Apply(BookingCreatedEvent e)
        {
            this.Booking = e.Booking;
        }

        public void Apply(BookingCancelledEvent e)
        {
            this.Booking.SetStatus(BookingStatus.Cancelled);
        }

        public void Apply(BookingCheckedOutEvent e)
        {
            this.Booking.SetStatus(BookingStatus.CheckedOut);
        }

        public void Create(Booking booking)
        {
            Emit(new BookingCreatedEvent(booking));
        }

        public void Cancel()
        {
            if (this.Booking.Status == BookingStatus.CheckedOut)
            {
                throw DomainError.With("The booking is already checked out and cannot be cancelled!");
            }

            Emit(new BookingCancelledEvent());
        }

        public void Checkout()
        {
            Emit(new BookingCheckedOutEvent());
        }
    }
}
