﻿using System;
using EventFlow.Core;

namespace HolidayInn.Models
{
    public class BookingId : Identity<BookingId>
    {
        public BookingId(string value) : base(value) { }
    }
}
