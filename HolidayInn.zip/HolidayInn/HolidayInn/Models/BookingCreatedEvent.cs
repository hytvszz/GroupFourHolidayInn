﻿using System;
using EventFlow.Aggregates;

namespace HolidayInn.Models
{
    public class BookingCreatedEvent : AggregateEvent<BookingAggregate, BookingId>
    {
        public Booking Booking { get; private set; }

        public BookingCreatedEvent(Booking booking)
        {
            this.Booking = booking;
        }
    }
}
