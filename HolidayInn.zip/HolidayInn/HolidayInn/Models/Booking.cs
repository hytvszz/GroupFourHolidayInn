﻿using System;
namespace HolidayInn.Models
{
    public class Booking
    {
        public BookingId Id { get; private set; }
        public string CustomerName { get; private set; }
        public string Phone { get; private set; }
        public string Email { get; private set; }
        public DateTime CheckinDate { get; private set; }
        public DateTime CheckoutDate { get; private set; }
        public BookingStatus Status { get; private set; }

        public Booking(BookingId id, string name, string phone, string email, DateTime checkinDate, DateTime checkoutDate, BookingStatus status)
        {
            this.Id = id;
            this.CustomerName = name;
            this.Phone = phone;
            this.Email = email;
            this.CheckinDate = checkinDate;
            this.CheckoutDate = checkoutDate;
            this.Status = status;
        }

        public void SetStatus(BookingStatus status)
        {
            this.Status = status;
        }
    }
}
