﻿using System;
namespace HolidayInn.Models
{
    public enum BookingStatus
    {
        Created,
        CheckedIn,
        CheckedOut,
        Cancelled
    }
}
