﻿using System;
using System.Collections.Generic;
using EventFlow;
using EventFlow.Configuration;
using EventFlow.Extensions;

namespace HolidayInn.Models
{
    public static class MyResolver
    {
        private static IRootResolver resolver;

        public static IRootResolver GetResolver()
        {
            var events = new List<Type>
            {
                typeof(BookingCreatedEvent),
                typeof(BookingCancelledEvent),
                typeof(BookingCheckedOutEvent)
            };
            var commands = new List<Type>
            {
                typeof(CreateBookingCommand),
                typeof(CancelBookingCommand),
                typeof(CheckoutBookingCommand)
            };
            var handlers = new List<Type>
            {
                typeof(CreateBookingCommandHandler),
                typeof(CancelBookingCommandHandler),
                typeof(CheckoutBookingCommandHandler)
            };
            if (resolver == null)
            {
                resolver = EventFlowOptions.New
                      .AddEvents(events)
                      .AddCommands(commands)
                      .AddCommandHandlers(handlers)
                      .UseInMemoryReadStoreFor<BookingReadModel>()
                      .CreateResolver();
            }
            return resolver;
        }
    }
}
