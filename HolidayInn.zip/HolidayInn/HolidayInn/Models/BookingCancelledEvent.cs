﻿using System;
using EventFlow.Aggregates;

namespace HolidayInn.Models
{
    public class BookingCancelledEvent : AggregateEvent<BookingAggregate, BookingId>
    {
        public BookingCancelledEvent()
        {
        }
    }
}
