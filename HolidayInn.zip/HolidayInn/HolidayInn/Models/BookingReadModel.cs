﻿using System;
using EventFlow.Aggregates;
using EventFlow.ReadStores;

namespace HolidayInn.Models
{
    public class BookingReadModel : IReadModel,
  IAmReadModelFor<BookingAggregate, BookingId, BookingCreatedEvent>,
  IAmReadModelFor<BookingAggregate, BookingId, BookingCancelledEvent>,
  IAmReadModelFor<BookingAggregate, BookingId, BookingCheckedOutEvent>
    {
        public Booking Booking { get; set; }

        public void Apply(
          IReadModelContext context,
          IDomainEvent<BookingAggregate, BookingId, BookingCreatedEvent> e)
        {
            this.Booking = e.AggregateEvent.Booking;
        }

        public void Apply(IReadModelContext context, IDomainEvent<BookingAggregate, BookingId, BookingCancelledEvent> domainEvent)
        {
            this.Booking.SetStatus(BookingStatus.Cancelled);
        }

        public void Apply(IReadModelContext context, IDomainEvent<BookingAggregate, BookingId, BookingCheckedOutEvent> domainEvent)
        {
            this.Booking.SetStatus(BookingStatus.CheckedOut);
        }
    }
}
