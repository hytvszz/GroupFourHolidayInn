﻿using System;
using System.Threading;
using System.Threading.Tasks;
using EventFlow.Aggregates.ExecutionResults;
using EventFlow.Commands;

namespace HolidayInn.Models
{
    public class CheckoutBookingCommandHandler : CommandHandler<BookingAggregate, BookingId, IExecutionResult, CheckoutBookingCommand>
    {
        public CheckoutBookingCommandHandler()
        {
        }

        public override System.Threading.Tasks.Task<IExecutionResult> ExecuteCommandAsync(BookingAggregate aggregate, CheckoutBookingCommand command, CancellationToken cancellationToken)
        {
            aggregate.Checkout();
            return Task.FromResult(ExecutionResult.Success());
        }
    }
}
