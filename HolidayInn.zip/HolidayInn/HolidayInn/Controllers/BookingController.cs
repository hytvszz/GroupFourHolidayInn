﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using EventFlow;
using HolidayInn.Models;

namespace HolidayInn.Controllers
{
    public class BookingController : Controller
    {
        public async Task<ActionResult> Index()
        {
            return View();
        }

        public async Task<ActionResult> Create()
        {
            var resolver = MyResolver.GetResolver();

            var bookingId = BookingId.New;

            var booking = new Booking
            (bookingId, "", "", "", DateTime.Now, DateTime.Now, BookingStatus.Created);

            var commandBus = resolver.Resolve<ICommandBus>();
            var executionResult = await commandBus.PublishAsync(
                new CreateBookingCommand(booking),
                CancellationToken.None)
                .ConfigureAwait(false);

            return View();
        }

        public async Task<ActionResult> Cancel()
        {
            var resolver = MyResolver.GetResolver();

            var bookingId = BookingId.With("12345667");

            var commandBus = resolver.Resolve<ICommandBus>();
            var executionResult = await commandBus.PublishAsync(
                new CancelBookingCommand(bookingId),
                CancellationToken.None)
                .ConfigureAwait(false);

            return View();
        }

        public async Task<ActionResult> Checkout()
        {
            var resolver = MyResolver.GetResolver();

            var bookingId = BookingId.With("12345667");

            var commandBus = resolver.Resolve<ICommandBus>();
            var executionResult = await commandBus.PublishAsync(
                new CheckoutBookingCommand(bookingId),
                CancellationToken.None)
                .ConfigureAwait(false);

            return View();
        }

        public Booking NewBooking()
        {
            var bookingId = BookingId.New;

            return new Booking
            (bookingId, "Test", "", "", DateTime.Now, DateTime.Now, BookingStatus.Created);
        }
    }
}
